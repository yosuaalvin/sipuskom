<div id="page-wrapper">
    <div class="row">
    <div class="col-md-12">
    <h2 class="page-header">
    Kursus  <small>Data Peserta</small>
    </h2>
    </div>
</div> 
<!-- /. ROW  -->
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                </div>
            <div class="panel-body">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover" >
            <thead>
                <tr class="danger">
                    <th><b>No</b></th>
                    <th><b>NPM</b></th>
                    <th><b>Nama</b></th>
                    <th><b>Nama Kursus</b></th>
                    <th><b>Kelas</b></th>
                    <th><b>Jurusan</b></th>
                    <th><b>Aksi</b></th>
                    </tr>
            </thead>
            <tbody>
            <?php 
             $no=1;
            foreach($peserta as $b):?>
              <tr>
              <td><?php echo $no++?></td>
              <td><?php echo $b->npm?></td>
              <td><?php echo $b->nama?></td>
              <td><?php echo $b->nm_kursus?></td>
              <td><?php echo $b->kelas?></td> 
              <td><?php echo $b->jurusan?></td>  
              <td><a href="<?php echo base_url();?>admin/welcome/ubah_ps/<?php echo $b->id;?>" class="btn btn-sm btn-default"><span class="glyphicon glyphicon-edit"></span></a>
              <a href="<?php echo base_url();?>admin/welcome/hapus_ps/<?php echo $b->id;?>" onClick="return checkMe()" class="btn btn-sm btn-default"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>                                   
            <tr class="gradeU">                                
            <td class="center">
            </td>
            </tr>
            <?php endforeach?>
            </tbody>
            </tr>
            </table>
            </div>
            </div>
            </div>
        </div>
    </div>