<div id="page-wrapper">
    <div class ="container-fluid">
        <div class="row">
        <div class="col-lg-12">
        <h1 class="page-header" >Edit Peserta</h1>
            </div>
            <div class="row">
            <div class="col-lg-12">
            <div class="panel panel-primary">
            <div class="panel-heading">
            Silahkan mengubah peserta kursus
            </div>
            <div class="panel-body">
            <form action="<?php echo base_url()?>admin/welcome/ubah_ps/<?php  echo $peserta->id?>" method="post">
            <div class="form-group">
            <table class="table" border=1>
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>NPM</th>
                            <th>:</th>
                            <th><input type="text" size=50 name="npm" value="<?php echo $peserta->npm?>"></th>
                        </tr>
                        <tr>
                            <th>Nama</th>
                            <th>:</th>
                            <th><input type="text" name="nama" size=50 value="<?php echo $peserta->nama?>"></th>
                        </tr>
                        <tr>
                            <th>Nama Kursus</th>
                            <th>:</th>
                            <th><input type="text" size=50 name="nm_kursus" value="<?php echo $peserta->nm_kursus?>"></th>
                        </tr>
                        <tr>
                            <th>Periode</th>
                            <th>:</th>
                            <th><input type="date" name="periode" value="<?php echo $peserta->periode?>"></th>
                        </tr>
                        <tr>
                            <th>Kelas</th>
                            <th>:</th>
                            <th><input type="text" name="kelas" size=50 value="<?php echo $peserta->kelas?>"></th>
                        </tr>
                        <tr>
                            <th>Jurusan</th>
                            <th>:</th>
                            <th>
                             <select name="jurusan" value="<?php echo $peserta->jurusan?>">
                                <option value="Teknik Informatika">Teknik Informatika</option>
                                <option value="Sistem Informasi">Sistem Informasi</option>
                                <option value="Manajemen Informatika">Manajemen Informatika</option>
                            </select>
                            </th>
                        </tr>
                        </thead>
                    </table>
            </div><hr>
                     <input type="submit" class="btn btn-primary" value="Ubah" name="submit"/>
            </div>
            </div>
            </div>   
            </div>
            </div>
        </div>
        </div>
    </div>
</div>
    