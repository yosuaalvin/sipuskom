<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
  public function __construct() 
  {
	parent::__construct();
  $this->load->model(array('m_admin','admin_kursus','m_login','admin_peserta'));
  $this->load->database();
  }

  function index()
  {
       if($this->session->userdata('level') != 2){
            redirect('login');
        }else{
            $this->load->model('m_admin');
            $user = $this->session->userdata('username');
            $this->data['level'] = $this->session->userdata('level');        
            $this->data['pengguna'] = $this->m_admin->data($user);
            $this->load->view('admin/header',$this->data);
            $this->load->view('admin/index',$this->data);
            $this->load->view('admin/footer');
        }      
  }
  function kursus()
  {
    $query = $this->admin_kursus->selectAll();
    $data['internet'] = $query;
    $user = $this->session->userdata('username');
            $this->data['pengguna'] = $this->m_admin->data($user);
    $this->load->view('admin/header',$this->data);
    $this->load->view('admin/kursus',$data);
    $this->load->view('admin/footer');
  }
  function tambah_data()
  {
    //$data['kursus']=$this->admin_kursus->tambah_kursus(); 
    $user = $this->session->userdata('username');
    $this->data['pengguna'] = $this->m_login->data($user);
    $this->load->view('admin/header',$this->data);
    $this->load->view('admin/form_tambah');
    $this->load->view('admin/footer');
  }
  function tambah_kursus()
  {
    $nama_kursus=$this->input->post('nama_kursus');
    $lepkom=$this->input->post('lepkom');
    $periode=$this->input->post('periode');
    $harga=$this->input->post('harga');
    $kuota=$this->input->post('kuota');
    $this->admin_kursus->tambah_kursus($nama_kursus,$lepkom,$periode,$harga,$kuota); 
    redirect('admin/welcome/kursus');
  }
  function hapus($id)
  {
        $this->admin_kursus->delete($id);
        redirect('admin/welcome/kursus');
  }
  function ubah($id) 
  {
        if($_POST==NULL) {
            $data['dt_kursus'] = $this->admin_kursus->select($id);
            $user = $this->session->userdata('username');
            $this->data['pengguna'] = $this->m_login->data($user);
            $this->load->view('admin/header',$this->data);
            $this->load->view('admin/edit_form_tambah',$data);
            $this->load->view('admin/footer');
        }else {
            $nama_kursus=$this->input->post('nama_kursus');
            $lepkom=$this->input->post('lepkom');
            $periode=$this->input->post('periode');
            $harga=$this->input->post('harga');
            $kuota=$this->input->post('kuota');
            $this->admin_kursus->update($id,$nama_kursus,$lepkom,$periode,$harga,$kuota); 
            redirect('admin/welcome/kursus');
        }
  }

function lock_kursus($id){
            $status=1;
            $this->admin_kursus->lock_kursus($id,$status); 
            redirect('admin/welcome/kursus');

}

function unlock_kursus($id){
            $status=0;
            $this->admin_kursus->unlock_kursus($id,$status); 
            redirect('admin/welcome/kursus');

}

  function peserta()
  {
    $query = $this->admin_peserta->selectAll();
    $data['peserta']=$query;
    $user = $this->session->userdata('username');
    $this->data['pengguna'] = $this->m_login->data($user);
    $this->load->view('admin/header',$this->data);
    $this->load->view('admin/peserta',$data);
    $this->load->view('admin/footer');
  }
  function hapus_ps($id)
  {
        $this->admin_peserta->delete($id);
        redirect('admin/welcome/peserta');
  }
  function ubah_ps($id) 
  {
         if($_POST==NULL) {
            $data['peserta'] = $this->admin_peserta->select($id);
            $user = $this->session->userdata('username');
            $this->data['pengguna'] = $this->m_login->data($user);
            $this->load->view('admin/header',$this->data);
            $this->load->view('admin/edit_peserta',$data);
            $this->load->view('admin/footer');
        }else {
            $npm=$this->input->post('npm');
            $nama=$this->input->post('nama');
            $nm_kursus=$this->input->post('nm_kursus');
            $periode=$this->input->post('periode');
            $kelas=$this->input->post('kelas');
            $jurusan=$this->input->post('jurusan');
            $this->admin_peserta->update($id,$npm,$nama,$nm_kursus,$periode,$kelas,$jurusan); 
            redirect('admin/welcome/peserta');
        }
  }
  function login()
  {
    $session = $this->session->userdata('isLogin');
      if($session == FALSE)
      {
          $this->load->view('admin/index');
      }else
      {
          redirect('admin/welcome');
      }
  }
  function logout()
  {
    $this->session->unset_userdata('Login');
    redirect('welcome','refresh');
  }
}